<h2> Propósito </h2>

El propósito de estos archivos es que puedas tener una base para implementar lo explicado en los video tutoriales.
En mi sitio web puedes ver cada uno de los tutoriales que explican paso por paso como se implementa el código que encuentras aquí.  

<h3> Especificaciones </h3>

Los videos pueden ser encontrados en mi sitio web, el cuál, provee el enlace para descargar todos los archivos.  
Una vez descargas el archivo podrás ver que está subdividido por directorios con un número de código.  Ese código es el que 
aparece al final del enlace y es el mismo código del video de YouTube.

<b><i>Ej.</i></b>

Entras a <a href="http://lopezpagan.com/listar-anadir-editar-borrar-records-con-dreamweaver-y-php/" target="_blank">aquí</a>.  
Busca el enlace y observa el código que está al final en negrillas <b>"bold"</b>.  
El directorio que contiene el código <b>ieeRfZEFOAc</b> es el que corresponde a este tutorial.

<b>Descarga el proyecto:</b>
<a href="https://github.com/lopezpagan/youtube-tutorials/tree/master/ieeRfZEFOAc" target="_blank">https://github.com/lopezpagan/youtube-tutorials/tree/master/<b>ieeRfZEFOAc</b></a>

